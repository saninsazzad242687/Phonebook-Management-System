#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>
#include<windows.h>



void welcome();
void login();
void menu();
void add_new();
void list_number();
void search_number();
void modify();
void delete_number();
void exit();



int main()
{
    welcome();
    login();
}

void welcome()
{
  printf("                                   *******************************************                                   \n");
  printf("                                                   *Welcome to*                               \n");
  printf("                                           *Phonebook Management System*                                     \n");
  printf("                                     *******************************************                                   \n");
  printf("          Enter any key to continue........           \n");
  getch();
}



void login()
{
    system("cls");

    int g=0;
    char user,pass;
    char a[20],b[20];
    printf("                                            *************************************                                    \n");
    printf("\n                                                     log in screen                             \n");
    printf("\n                                        *************************************                                     \n");
    do
        {
           printf("\n        Enter username and password       \n");
           printf("\n        username:");
           scanf("%s",a);
           printf("\n        password:");
           scanf("%s",b);

           if(strlen(b)<6||strlen(b)>12)
            {
            printf("\n\nPlease enter password between 6 to 12 character");
           }
           else
            {
                if((strcmp(a,"BUBT_35_2")==0)&&(strcmp(b,"bubt123@")==0))
                    {
                       printf("\n        logged in to the system\n");
                       printf("any key to next................\n");
                       getch();
                       menu();
                   }
                   else
                   {
                       printf("\n        **Login failed**    \n");
                       printf("        **enter username and password again**        \n");
                       g++;
                   }
           }
        }
while(g<=2);


if(g>2)
    {
            printf("\n**********unknown user,you are not valid person to logged in********** ");
            getch();
    }
}



void menu()
{
    int select;
    system("cls");
    printf("                                               ***********************************                         \n");
    printf("                                                            Menu                         \n");
    printf("                                             ***********************************                         \n");

    printf("1. Add New\n");
    printf("2. List Number\n");
    printf("3. Search Number\n");
    printf("4. Modify\n");
    printf("5. Delete\n");
    printf("6. Exit\n");
    printf("\nselect your number[1-6]:");
    scanf("%d",&select);
    switch(select)
    {
    case 1:
        add_new();
        break;
    case 2:
        list_number();
        break;
    case 3:
        search_number();
        break;
    case 4:
        modify();
        break;

    case 5:
        delete_number();
        break;
    case 6:
        exit();
        break;
    default:
        printf("wrong number");
        exit(0);
    }
}
//Add new function
void add_new()
{
    system("cls");

    FILE*fp;

    fp=fopen("project.txt","a+");

    printf("                                            ******************************                                   \n");
    printf("                                                       Add New                                          \n");
    printf("                                              ******************************                                   \n");

    printf("\n Enter Name: ");
    char name[15];
    scanf("%s",name);
    printf("\n Enter Address: ");
    char address[15];
    scanf("%s",address);
    printf("\n Enter Email: ");
    char email[15];
    scanf("%s",email);
    printf("\n Enter Mobile number: ");
    char mobile_no[15];
    scanf("%s",mobile_no);
    printf("\n Enter Gender: ");
    char gender[15];
    scanf("%s",gender);
    printf("\n Enter City: ");
    char city[15];
    scanf("%s",city);
    fprintf(fp,"%s %s %s %s %s %s\n",name,address,email,mobile_no,gender,city);
    printf("\n record saved!!\n");
    fclose(fp);
    printf("\n any key to continue");
    getch();
    menu();
}



void list_number()
{

    FILE*fp;

    fp=fopen("project.txt","r");
     system("cls");
    printf("                                               ******************************                                 \n");
    printf("                                                      List Number                                        \n");
    printf("                                             ******************************                                 \n");

    char name[15], address[15], email[15], mobile_no[15], gender[15], city[15];
    printf("Name:\t\t\tAddress:\t\tEmail:\t\t\tMobile_no:\t\tGender:\t\t\tCity:\t\n");
    while(fscanf(fp,"%s %s %s %s %s %s",name,address,email,mobile_no,gender,city)!=EOF)
    {

        printf("%-20s\t%-20s\t%-20s\t%-20s\t%-20s\t%-20s\t \n",name,address,email,mobile_no,gender,city);
    }
    fclose(fp);
    printf("\n Enter any key to continue..");
    getch();
    menu();
}
void search_number()
{
   FILE*fp;
    fp=fopen("project.txt","r");
     system("cls");
    printf("                                             ******************************                                  \n");
    printf("                                                       Search Number                                          \n");
    printf("                                                ******************************                                   \n");
    printf("\n Enter name to search: ");
    char name1[15];
    scanf("%s",name1);

    char name[15], address[15], email[15], mobile_no[15], gender[15], city[15];
    while(fscanf(fp,"%s %s %s %s %s %s",name,address,email,mobile_no,gender,city)!=EOF)
    {

            if(strcmp(name1,name)==0)
    {

        printf("\n NAME: %s",name);
        printf("\n ADDRESS: %s",address);
        printf("\n EMAIL: %s",email);
        printf("\n MOBILE NO: %s",mobile_no);
        printf("\n GENDER: %s",gender);
        printf("\n CITY: %s",city);
    }
     //else if(strcmp(name1,name)==1)
    //{
        //printf(" data not found\n");
     //}
    }
    fclose(fp);
    printf("\n any key to continue");
    getch();
    menu();
}
void modify()
{
   FILE *fp,*fp1;
   char name[15], address[15], email[15], mobile_no[15], gender[15], city[15],name1[20];
   int res,f=0;

    system("cls");
    printf("                                                ******************************                              \n");
    printf("                                                    Modify Number                                     \n");
    printf("                                             ******************************                              \n");
    fp=fopen("project.txt","r");
   fp1=fopen("temp.txt","a");
   printf("Enter name to modify: ");
   scanf("%s",name1);
   while(fscanf(fp,"%s %s %s %s %s %s",name,address,email,mobile_no,gender,city)!=EOF)
   {
      res=strcmp(name,name1);
      if(res==0)
      {
      f=1;
            printf("\nEnter Name: ");
            scanf("%s",name);
            printf("Enter Address: ");
            scanf("%s",address);
            printf("Enter Email: ");
            scanf("%s",email);
            printf("Enter Mobile no: ");
            scanf("%s",mobile_no);
            printf("Enter Gender: ");
            scanf("%s",gender);

            printf("Enter City: ");

        scanf("%s",city);
        fprintf(fp1,"%s %s %s %s %s %s\n",name,address,email,mobile_no,gender,city);

      }
      else
      {
      fprintf(fp1,"%s %s %s %s %s %s\n",name,address,email,mobile_no,gender,city);
      }
   }
   if(f==0)
   {
   printf("Name not found");
   }
   fclose(fp);
   fclose(fp1);
   fp=fopen("project.txt","w");
   fclose(fp);


   fp=fopen("project.txt","a");
   fp1=fopen("temp.txt","r");
   while(fscanf(fp1,"%s %s %s %s %s %s",name,address,email,mobile_no,gender,city)!=EOF)
   {
    fprintf(fp,"%s %s %s %s %s %s\n",name,address,email,mobile_no,gender,city);

   }
   fclose(fp);
   fclose(fp1);
   fp=fopen("temp.txt","w");
   fclose(fp);
   printf("\nAny Key To Continue...\n");
   printf("\n record saved!!\n");
    getch();
    menu();
}


void delete_number()
{
    FILE*fp,*fp1;
    fp=fopen("project.txt","r+");
    fp1=fopen("temp.txt","w");
     system("cls");
    printf("                                             ******************************                              \n");
    printf("                                                    Delete Number                                     \n");
    printf("                                                ******************************                              \n");
    printf("\n Enter name to delete: ");
    char name[15];
    scanf("%s",name);
    char name1[15], address[15], email[15], mobile_no[15], gender[15], city[15];
    while(fscanf(fp,"%s %s %s %s %s %s",name1,address,email,mobile_no,gender,city)!=EOF)
    {
        if(strcmp(name,name1)==0)
        {
            continue;
        }
        fprintf(fp1,"%s %s %s %s %s %s\n",name1,address,email,mobile_no,gender,city);
    }
    fclose(fp);
    fclose(fp1);
    fp=fopen("project.txt","w");
    fp1=fopen("temp.txt","r");
    while(fscanf(fp1,"%s %s %s %s %s %s",name1,address,email,mobile_no,gender,city)!=EOF)
    {
        fprintf(fp,"%s %s %s %s %s %s\n",name1,address,email,mobile_no,gender,city);
    }
    fclose(fp);
    fclose(fp1);
    remove("temp.txt");
    printf("\nAny Key To Continue...");
    getch();
    menu();
}

void exit()
{
    system("cls");
    welcome();
}
